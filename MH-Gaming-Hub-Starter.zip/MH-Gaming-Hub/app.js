(() => {
const $ = id => document.getElementById(id);
const KEY='mhGamingHub.v1';
let state;
try { state=JSON.parse(localStorage.getItem(KEY)) || {}; } catch { state={}; }
state={coins:0,xp:0,played:0,scores:{},lastCheckin:'',...state};
let activeGame=null, timer=null, snakeLoop=null, sound=true;
const today=()=>new Date().toLocaleDateString('en-CA');
function save(){localStorage.setItem(KEY,JSON.stringify(state));renderStats();}
function level(){return Math.floor(state.xp/100)+1;}
function renderStats(){
$('coins').textContent=state.coins;$('xp').textContent=state.xp;$('level').textContent=level();$('levelChip').textContent='LVL '+level();
$('played').textContent=state.played;let within=state.xp%100;$('xpLabel').textContent=within+' / 100 XP';$('xpBar').style.width=within+'%';
}
let toastTimer;
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2300);}
function award(game,points,bonus=5){
state.played++;state.xp+=Math.max(5,bonus);state.coins+=Math.max(1,Math.floor(points/5));state.scores[game]=Math.max(state.scores[game]||0,points);save();
$('gameMessage').textContent=`Score: ${points} • +${Math.max(5,bonus)} XP`;toast(`Nice! +${Math.max(5,bonus)} XP and coins earned.`);
}
function openGame(name){
clearInterval(timer);clearInterval(snakeLoop);activeGame=name;$('gameModal').hidden=false;$('gameArea').innerHTML='';$('gameMessage').textContent='Have fun!';
const titles={snake:'Snake Rush',memory:'Memory Match',target:'Target Tap',puzzle:'Number Slide'};
$('gameTitle').textContent=titles[name];$('gameType').textContent=name.toUpperCase()+' GAME';runGame(name);
}
function closeGame(){clearInterval(timer);clearInterval(snakeLoop);$('gameModal').hidden=true;activeGame=null;}
function runGame(name){if(name==='snake')startSnake();if(name==='memory')startMemory();if(name==='target')startTarget();if(name==='puzzle')startPuzzle();}
function restart(){if(activeGame)openGame(activeGame);}
function startSnake(){
const area=$('gameArea');
area.innerHTML='<div class="game-note">Use the arrow buttons to steer. Collect green food and avoid the edges.</div><canvas class="game-canvas" id="snakeCanvas" width="320" height="320"></canvas><div class="game-controls"><button data-dir="up">▲</button><button data-dir="left">◀</button><button data-dir="down">▼</button><button data-dir="right">▶</button></div><div class="game-note" id="snakeScore">Score: 0</div>';
const c=$('snakeCanvas'),ctx=c.getContext('2d'),cell=16,cols=20,rows=20;let body=[{x:9,y:10},{x:8,y:10},{x:7,y:10}],dir={x:1,y:0},next={x:1,y:0},food={x:14,y:10},score=0,over=false;
function placeFood(){do{food={x:Math.floor(Math.random()*cols),y:Math.floor(Math.random()*rows)}}while(body.some(p=>p.x===food.x&&p.y===food.y));}
function draw(){ctx.fillStyle='#080e1d';ctx.fillRect(0,0,320,320);ctx.strokeStyle='#16233a';for(let i=0;i<=20;i++){ctx.beginPath();ctx.moveTo(i*cell,0);ctx.lineTo(i*cell,320);ctx.stroke();ctx.beginPath();ctx.moveTo(0,i*cell);ctx.lineTo(320,i*cell);ctx.stroke();}
ctx.fillStyle='#8cf7b1';ctx.beginPath();ctx.arc(food.x*cell+8,food.y*cell+8,6,0,Math.PI*2);ctx.fill();
body.forEach((p,i)=>{ctx.fillStyle=i?'#45bdb9':'#8cf7b1';ctx.beginPath();ctx.roundRect(p.x*cell+1,p.y*cell+1,cell-2,cell-2,4);ctx.fill();});}
function tick(){if(over)return;dir=next;const head={x:body[0].x+dir.x,y:body[0].y+dir.y};if(head.x<0||head.x>=cols||head.y<0||head.y>=rows||body.some(p=>p.x===head.x&&p.y===head.y)){over=true;clearInterval(snakeLoop);$('gameMessage').textContent='Game over • Score '+score;if(score>0)award('Snake Rush',score,10+score);return;}
body.unshift(head);if(head.x===food.x&&head.y===food.y){score+=10;$('snakeScore').textContent='Score: '+score;placeFood();}else body.pop();draw();}
$('gameArea').querySelectorAll('[data-dir]').forEach(b=>b.addEventListener('click',()=>{const d=b.dataset.dir,dirs={up:{x:0,y:-1},down:{x:0,y:1},left:{x:-1,y:0},right:{x:1,y:0}};const nd=dirs[d];if(nd.x!==-dir.x||nd.y!==-dir.y)next=nd;}));
draw();snakeLoop=setInterval(tick,145);
}
function startMemory(){
const area=$('gameArea'),icons=['🍉','🚀','🎮','⭐','🍀','👾','💎','⚡'];let deck=[...icons,...icons].sort(()=>Math.random()-.5),first=null,lock=false,matches=0,moves=0;
area.innerHTML='<div class="game-note">Flip two cards and find every matching pair.</div><div class="memory-grid" id="memoryGrid"></div><div class="game-note" id="memoryStatus">Pairs: 0 / 8 • Moves: 0</div>';
const grid=$('memoryGrid');
deck.forEach((icon,i)=>{const b=document.createElement('button');b.className='memory-tile';b.textContent='?';b.dataset.icon=icon;b.dataset.i=i;b.addEventListener('click',()=>{if(lock||b.classList.contains('revealed')||b.classList.contains('matched'))return;b.textContent=icon;b.classList.add('revealed');if(!first){first=b;return;}moves++;if(first.dataset.icon===b.dataset.icon){first.classList.add('matched');b.classList.add('matched');first=null;matches++;$('memoryStatus').textContent=`Pairs: ${matches} / 8 • Moves: ${moves}`;if(matches===8){$('gameMessage').textContent='All pairs found!';award('Memory Match',Math.max(20,100-moves*3),20);}}else{lock=true;const prev=first;first=null;setTimeout(()=>{prev.textContent='?';b.textContent='?';prev.classList.remove('revealed');b.classList.remove('revealed');lock=false;},650);}$('memoryStatus').textContent=`Pairs: ${matches} / 8 • Moves: ${moves}`;});grid.appendChild(b);});
}
function startTarget(){
const area=$('gameArea');area.innerHTML='<div class="game-note">Tap as many targets as you can in 20 seconds!</div><div class="target-field" id="targetField"></div><div class="game-note" id="targetStatus">Time: 20s • Hits: 0</div><button class="primary-btn small" id="targetStart">START ROUND</button>';
const field=$('targetField');let hits=0,left=20,started=false,ended=false;
function spawn(){field.innerHTML='';const b=document.createElement('button');b.className='target-dot';b.setAttribute('aria-label','Tap target');b.style.left=Math.floor(Math.random()*(field.clientWidth-50))+'px';b.style.top=Math.floor(Math.random()*(field.clientHeight-50))+'px';b.addEventListener('click',()=>{if(ended)return;hits++;$('targetStatus').textContent=`Time: ${left}s • Hits: ${hits}`;spawn();});field.appendChild(b);}
$('targetStart').addEventListener('click',()=>{if(started)return;started=true;$('targetStart').disabled=true;spawn();timer=setInterval(()=>{left--;$('targetStatus').textContent=`Time: ${left}s • Hits: ${hits}`;if(left<=0){ended=true;clearInterval(timer);field.innerHTML='<div class="game-note" style="padding:100px 15px">Round complete!</div>';award('Target Tap',hits*10,10+hits);}},1000);});
}
function startPuzzle(){
const area=$('gameArea');let nums=[1,2,3,4,5,6,7,8,0];do{nums=[1,2,3,4,5,6,7,8,0].sort(()=>Math.random()-.5);}while(!solvable(nums)||nums.every((n,i)=>n===(i===8?0:i+1)));
let moves=0;area.innerHTML='<div class="game-note">Arrange the numbers from 1 to 8. Tap a tile beside the empty space.</div><div class="number-grid" id="numberGrid"></div><div class="game-note" id="puzzleStatus">Moves: 0</div><button class="plain-btn" id="puzzleShuffle">Shuffle</button>';const grid=$('numberGrid');
function solvable(a){let inv=0;for(let i=0;i<a.length;i++)for(let j=i+1;j<a.length;j++)if(a[i]&&a[j]&&a[i]>a[j])inv++;return inv%2===0;}
function draw(){grid.innerHTML='';nums.forEach((n,i)=>{const b=document.createElement('button');b.className='number-tile'+(!n?' empty':'');b.textContent=n||'';b.addEventListener('click',()=>{const z=nums.indexOf(0);if(!n||![z-3,z+3,...(z%3?[z-1]:[]),...(z%3<2?[z+1]:[])].includes(i))return;[nums[z],nums[i]]=[nums[i],nums[z]];moves++;$('puzzleStatus').textContent='Moves: '+moves;draw();if(nums.every((v,k)=>v===(k===8?0:k+1))){$('gameMessage').textContent='Puzzle solved!';award('Number Slide',Math.max(10,100-moves),20);}});grid.appendChild(b);});}
$('puzzleShuffle').addEventListener('click',()=>{do{nums=[1,2,3,4,5,6,7,8,0].sort(()=>Math.random()-.5);}while(!solvable(nums)||nums.every((n,i)=>n===(i===8?0:i+1)));moves=0;$('puzzleStatus').textContent='Moves: 0';draw();});draw();
}
function showScores(){const rows=Object.entries(state.scores||{});$('gameTitle').textContent='Your Best Scores';$('gameType').textContent='PLAYER STATS';$('gameArea').innerHTML=rows.length?'<div class="score-list">'+rows.map(([k,v])=>`<div class="score-row"><strong>${escapeHtml(k)}</strong><span>${v} points</span></div>`).join('')+'</div>':'<div class="game-note">No scores yet. Play a game to set your first record!</div>';$('gameMessage').textContent='Saved on this device';$('gameModal').hidden=false;activeGame=null;clearInterval(timer);clearInterval(snakeLoop);}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
$('playNow').addEventListener('click',()=>$('games').scrollIntoView({behavior:'smooth'}));
document.querySelectorAll('[data-game]').forEach(b=>b.addEventListener('click',()=>openGame(b.dataset.game)));
$('closeGame').addEventListener('click',closeGame);$('restartGame').addEventListener('click',restart);
$('gameModal').addEventListener('click',e=>{if(e.target===$('gameModal'))closeGame();});
$('checkin').addEventListener('click',()=>{if(state.lastCheckin===today()){toast('You already checked in today!');return;}state.lastCheckin=today();state.coins+=10;state.xp+=5;save();toast('Daily check-in complete: +10 coins, +5 XP!');});
$('scoresNav').addEventListener('click',showScores);
$('profileNav').addEventListener('click',()=>toast('Guest profile is saved locally on this device.'));
$('soundBtn').addEventListener('click',()=>{sound=!sound;$('soundBtn').textContent=sound?'🔊':'🔇';toast(sound?'Sound indicator enabled':'Sound indicator muted');});
$('homeNav').addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
renderStats();
})();