const fs = require('fs');
const path = require('path');
const source = __dirname;
const dest = path.join(__dirname, 'www');
fs.mkdirSync(dest, { recursive: true });
for (const name of ['index.html', 'styles.css', 'app.js']) {
  fs.copyFileSync(path.join(source, name), path.join(dest, name));
}
console.log('Built web app into www/');
