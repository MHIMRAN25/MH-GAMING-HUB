# MH Gaming Hub (Android-ready starter)

This is a mobile-friendly gaming hub web app that can be packaged as an Android APK using a WebView wrapper or Capacitor.

## Included
- Home screen with game cards
- Snake game
- Memory match game
- Target tap game
- Puzzle number game
- Local high scores, XP, coins, level, daily check-in
- Responsive dark gaming UI
- No paid APIs or account credentials required

## Run locally
Open `index.html` in a browser, or host this folder using GitHub Pages.

## Make an Android APK
Recommended path:
1. Create a GitHub repository and upload the files in this folder.
2. To get a quick installable APK, use Android Studio with a WebView wrapper that loads `index.html`, or use Capacitor from a computer.
3. For Capacitor, on a computer with Node.js installed:
   - `npm install`
   - `npm run build` (copies the web app to `www`)
   - `npx cap add android`
   - `npx cap open android`
   Then build the APK in Android Studio.

Note: Building a native APK generally requires Android build tooling, usually Android Studio on a computer or a compatible cloud build. This starter itself is a working web app, not a prebuilt APK.

All points and coins are local demo progress stored on the device. They are not cash and do not have withdrawal functionality.
